import type { OrderStatus } from "@prisma/client";

export const ORDER_STATUS_LABEL: Record<OrderStatus, string> = {
  PENDING: "Bekliyor",
  PREPARING: "Hazırlanıyor",
  COMPLETED: "Tamamlandı",
  CANCELLED: "İptal",
};

export const ORDER_STATUS_CLASS: Record<OrderStatus, string> = {
  PENDING: "bg-amber-100 text-amber-800 border-amber-200",
  PREPARING: "bg-blue-100 text-blue-800 border-blue-200",
  COMPLETED: "bg-emerald-100 text-emerald-800 border-emerald-200",
  CANCELLED: "bg-rose-100 text-rose-800 border-rose-200",
};

export const EXPENSE_CATEGORIES = [
  "Hammadde",
  "Personel",
  "Kira",
  "Fatura",
  "Ekipman",
  "Pazarlama",
  "Diğer",
] as const;
