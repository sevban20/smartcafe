import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import type { Role } from "@prisma/client";

export async function requireUser(roles?: Role[]) {
  const session = await getServerSession(authOptions);
  if (!session?.user) redirect("/giris");
  if (roles && !roles.includes(session.user.role)) redirect("/giris?hata=yetki");
  return session.user;
}

export async function getCurrentUser() {
  const session = await getServerSession(authOptions);
  return session?.user ?? null;
}
