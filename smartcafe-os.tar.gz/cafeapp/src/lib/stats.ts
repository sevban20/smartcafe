import { prisma } from "@/lib/prisma";

export function startOfDay(d = new Date()) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

export function addDays(d: Date, days: number) {
  const x = new Date(d);
  x.setDate(x.getDate() + days);
  return x;
}

export type RangeSummary = {
  income: number;
  expense: number;
  profit: number;
  orderCount: number;
};

export async function getSummary(from: Date, to: Date): Promise<RangeSummary> {
  const [grouped, orderCount] = await Promise.all([
    prisma.transaction.groupBy({
      by: ["type"],
      where: { date: { gte: from, lt: to } },
      _sum: { amount: true },
    }),
    prisma.order.count({
      where: { status: "COMPLETED", createdAt: { gte: from, lt: to } },
    }),
  ]);

  const income = grouped.find((g) => g.type === "INCOME")?._sum.amount ?? 0;
  const expense = grouped.find((g) => g.type === "EXPENSE")?._sum.amount ?? 0;

  return { income, expense, profit: income - expense, orderCount };
}

export type DailyPoint = { label: string; gelir: number; gider: number };

/** Son N gunun gunluk gelir/gider serisi (grafik icin) */
export async function getDailySeries(days = 7): Promise<DailyPoint[]> {
  const from = startOfDay(addDays(new Date(), -(days - 1)));
  const to = addDays(startOfDay(), 1);

  const transactions = await prisma.transaction.findMany({
    where: { date: { gte: from, lt: to } },
    select: { type: true, amount: true, date: true },
  });

  const buckets = new Map<string, DailyPoint>();
  for (let i = 0; i < days; i++) {
    const day = addDays(from, i);
    const key = day.toISOString().slice(0, 10);
    buckets.set(key, {
      label: new Intl.DateTimeFormat("tr-TR", { day: "2-digit", month: "short" }).format(day),
      gelir: 0,
      gider: 0,
    });
  }

  for (const t of transactions) {
    const key = startOfDay(t.date).toISOString().slice(0, 10);
    const bucket = buckets.get(key);
    if (!bucket) continue;
    if (t.type === "INCOME") bucket.gelir += t.amount;
    else bucket.gider += t.amount;
  }

  return Array.from(buckets.values());
}

/** En cok satan urunler (tamamlanmis siparisler uzerinden) */
export async function getTopProducts(from: Date, to: Date, take = 5) {
  const items = await prisma.orderItem.findMany({
    where: { order: { status: "COMPLETED", createdAt: { gte: from, lt: to } } },
    select: { productName: true, quantity: true, totalPrice: true },
  });

  const map = new Map<string, { name: string; quantity: number; revenue: number }>();
  for (const item of items) {
    const current = map.get(item.productName) ?? { name: item.productName, quantity: 0, revenue: 0 };
    current.quantity += item.quantity;
    current.revenue += item.totalPrice;
    map.set(item.productName, current);
  }

  return Array.from(map.values())
    .sort((a, b) => b.quantity - a.quantity)
    .slice(0, take);
}
