import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/guards";
import type { Prisma } from "@prisma/client";

export const dynamic = "force-dynamic";

const patchSchema = z.object({
  status: z.enum(["PENDING", "PREPARING", "COMPLETED", "CANCELLED"]),
});

/**
 * Siparis durumunu gunceller.
 * COMPLETED olunca otomatik GELIR kaydi olusur; iptal/geri alinca gelir kaydi silinir.
 */
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Yetkisiz" }, { status: 401 });

  const parsed = patchSchema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Geçersiz durum" }, { status: 400 });
  const { status } = parsed.data;

  const order = await prisma.order.findUnique({ where: { id: params.id } });
  if (!order) return NextResponse.json({ error: "Sipariş bulunamadı" }, { status: 404 });

  const updated = await prisma.$transaction(async (tx: Prisma.TransactionClient) => {
    const result = await tx.order.update({
      where: { id: params.id },
      data: { status },
      include: { orderItems: { include: { selectedOptions: true } } },
    });

    if (status === "COMPLETED") {
      const existing = await tx.transaction.findUnique({ where: { orderId: result.id } });
      if (!existing) {
        await tx.transaction.create({
          data: {
            type: "INCOME",
            amount: result.totalAmount,
            description: `Sipariş #${result.orderNo} · Masa ${result.tableNo}`,
            category: "Satış",
            orderId: result.id,
            date: new Date(),
          },
        });
      }
    } else {
      // Tamamlanmis durumdan cikildiysa otomatik gelir kaydini geri al
      await tx.transaction.deleteMany({ where: { orderId: result.id, type: "INCOME" } });
    }

    return result;
  });

  return NextResponse.json({ order: updated });
}

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const order = await prisma.order.findUnique({
    where: { id: params.id },
    include: { orderItems: { include: { selectedOptions: true } } },
  });
  if (!order) return NextResponse.json({ error: "Sipariş bulunamadı" }, { status: 404 });
  return NextResponse.json({ order });
}
