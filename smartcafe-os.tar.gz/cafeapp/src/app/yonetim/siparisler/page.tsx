import { prisma } from "@/lib/prisma";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatDate, formatPrice, formatTime } from "@/lib/utils";
import { ORDER_STATUS_CLASS, ORDER_STATUS_LABEL } from "@/lib/constants";
import type { Metadata } from "next";
import type { OrderStatus } from "@prisma/client";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Siparişler" };

const FILTERS: { key: string; label: string; statuses?: OrderStatus[] }[] = [
  { key: "hepsi", label: "Tümü" },
  { key: "aktif", label: "Aktif", statuses: ["PENDING", "PREPARING"] },
  { key: "tamamlanan", label: "Tamamlanan", statuses: ["COMPLETED"] },
  { key: "iptal", label: "İptal", statuses: ["CANCELLED"] },
];

export default async function SiparislerPage({ searchParams }: { searchParams: { durum?: string } }) {
  const active = FILTERS.find((f) => f.key === searchParams.durum) ?? FILTERS[0];

  const orders = await prisma.order.findMany({
    where: active.statuses ? { status: { in: active.statuses } } : undefined,
    orderBy: { createdAt: "desc" },
    take: 100,
    include: { orderItems: { include: { selectedOptions: true } } },
  });

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold">Siparişler</h1>
        <p className="text-sm text-muted-foreground">Son 100 sipariş</p>
      </div>

      <div className="no-scrollbar flex gap-2 overflow-x-auto">
        {FILTERS.map((f) => (
          <a
            key={f.key}
            href={`/yonetim/siparisler?durum=${f.key}`}
            className={`whitespace-nowrap rounded-full border px-3.5 py-1.5 text-sm ${
              active.key === f.key ? "border-primary bg-primary text-primary-foreground" : "text-muted-foreground"
            }`}
          >
            {f.label}
          </a>
        ))}
      </div>

      {orders.length === 0 ? (
        <Card className="p-8 text-center text-sm text-muted-foreground">Sipariş bulunamadı.</Card>
      ) : (
        <div className="space-y-3">
          {orders.map((order) => (
            <Card key={order.id} className="p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="font-semibold">
                    Masa {order.tableNo} · #{order.orderNo}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {formatDate(order.createdAt)} {formatTime(order.createdAt)}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className={ORDER_STATUS_CLASS[order.status]}>
                    {ORDER_STATUS_LABEL[order.status]}
                  </Badge>
                  <span className="font-bold tabular-nums">{formatPrice(order.totalAmount)}</span>
                </div>
              </div>

              <ul className="mt-3 space-y-1.5 border-t pt-3">
                {order.orderItems.map((item) => (
                  <li key={item.id} className="text-sm">
                    <span className="font-medium">
                      {item.quantity}× {item.productName}
                    </span>
                    {item.selectedOptions.length > 0 && (
                      <span className="text-muted-foreground">
                        {" — "}
                        {item.selectedOptions.map((o) => o.choiceName).join(", ")}
                      </span>
                    )}
                  </li>
                ))}
              </ul>

              {order.notes && (
                <p className="mt-2 rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-900">
                  <span className="font-semibold">Not:</span> {order.notes}
                </p>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
