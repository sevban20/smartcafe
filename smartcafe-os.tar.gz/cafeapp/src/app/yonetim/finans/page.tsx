import { TrendingDown, TrendingUp, Wallet, Percent } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { addDays, getDailySeries, getSummary, startOfDay } from "@/lib/stats";
import { StatCard } from "@/components/admin/stat-card";
import { FinanceChart } from "@/components/admin/finance-chart";
import { TransactionsPanel, type TransactionRow } from "@/components/admin/transactions-panel";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatPrice } from "@/lib/utils";
import type { Metadata } from "next";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Finans" };

export default async function FinansPage() {
  const today = startOfDay();
  const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
  const tomorrow = addDays(today, 1);

  const [summary, series, transactions] = await Promise.all([
    getSummary(monthStart, tomorrow),
    getDailySeries(14),
    prisma.transaction.findMany({
      orderBy: [{ date: "desc" }, { createdAt: "desc" }],
      take: 100,
    }),
  ]);

  const rows: TransactionRow[] = transactions.map((t) => ({
    id: t.id,
    type: t.type,
    amount: t.amount,
    description: t.description,
    category: t.category,
    date: t.date.toISOString(),
    isAutomatic: Boolean(t.orderId),
  }));

  const margin = summary.income > 0 ? (summary.profit / summary.income) * 100 : 0;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold">Finans</h1>
        <p className="text-sm text-muted-foreground">Bu ayın gelir, gider ve kâr durumu</p>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Gelir (bu ay)" value={formatPrice(summary.income)} icon={TrendingUp} tone="positive" />
        <StatCard label="Gider (bu ay)" value={formatPrice(summary.expense)} icon={TrendingDown} tone="negative" />
        <StatCard
          label="Net kâr"
          value={formatPrice(summary.profit)}
          icon={Wallet}
          tone={summary.profit >= 0 ? "positive" : "negative"}
        />
        <StatCard
          label="Kâr marjı"
          value={summary.income > 0 ? `%${margin.toFixed(1)}` : "—"}
          icon={Percent}
          hint={`${summary.orderCount} tamamlanan sipariş`}
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Son 14 gün</CardTitle>
        </CardHeader>
        <CardContent>
          <FinanceChart data={series} />
        </CardContent>
      </Card>

      <TransactionsPanel transactions={rows} />
    </div>
  );
}
