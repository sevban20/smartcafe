"use client";

import * as React from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, ChefHat, Loader2, RefreshCw, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatPrice, formatTime, timeAgo } from "@/lib/utils";
import { ORDER_STATUS_CLASS, ORDER_STATUS_LABEL } from "@/lib/constants";
import { toast } from "sonner";
import type { OrderStatus } from "@prisma/client";

type KdsOrder = {
  id: string;
  orderNo: number;
  tableNo: string;
  status: OrderStatus;
  totalAmount: number;
  notes: string | null;
  createdAt: string;
  orderItems: {
    id: string;
    productName: string;
    quantity: number;
    totalPrice: number;
    selectedOptions: { id: string; optionName: string; choiceName: string; extraPrice: number }[];
  }[];
};

const FILTERS = [
  { key: "AKTIF", label: "Aktif", statuses: "PENDING,PREPARING" },
  { key: "PENDING", label: "Bekleyen", statuses: "PENDING" },
  { key: "PREPARING", label: "Hazırlanan", statuses: "PREPARING" },
  { key: "COMPLETED", label: "Tamamlanan", statuses: "COMPLETED" },
] as const;

export function KdsBoard() {
  const [filter, setFilter] = React.useState<(typeof FILTERS)[number]["key"]>("AKTIF");
  const queryClient = useQueryClient();
  const statuses = FILTERS.find((f) => f.key === filter)!.statuses;

  const { data, isLoading, isFetching, refetch } = useQuery({
    queryKey: ["orders", statuses],
    queryFn: async () => {
      const res = await fetch(`/api/orders?status=${statuses}`, { cache: "no-store" });
      if (!res.ok) throw new Error("Siparişler alınamadı");
      return (await res.json()) as { orders: KdsOrder[] };
    },
    refetchInterval: 10_000,
  });

  const mutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: OrderStatus }) => {
      const res = await fetch(`/api/orders/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (!res.ok) throw new Error("Durum güncellenemedi");
      return res.json();
    },
    onSuccess: (_d, vars) => {
      queryClient.invalidateQueries({ queryKey: ["orders"] });
      toast.success(`Sipariş ${ORDER_STATUS_LABEL[vars.status].toLowerCase()} olarak işaretlendi`);
    },
    onError: () => toast.error("Durum güncellenemedi."),
  });

  const orders = data?.orders ?? [];

  return (
    <div className="min-h-[100dvh] bg-background pb-8">
      <header className="sticky top-0 z-30 border-b bg-background/95 px-4 py-3 backdrop-blur safe-top">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h1 className="text-lg font-bold leading-tight">Sipariş Ekranı</h1>
            <p className="text-xs text-muted-foreground">
              {orders.length} sipariş · 10 saniyede bir yenilenir
            </p>
          </div>
          <Button variant="outline" size="icon" onClick={() => refetch()} aria-label="Yenile">
            <RefreshCw className={`h-4 w-4 ${isFetching ? "animate-spin" : ""}`} />
          </Button>
        </div>

        <Tabs value={filter} onValueChange={(v) => setFilter(v as typeof filter)} className="mt-3">
          <TabsList className="no-scrollbar w-full justify-start overflow-x-auto">
            {FILTERS.map((f) => (
              <TabsTrigger key={f.key} value={f.key} className="flex-1">
                {f.label}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      </header>

      <div className="space-y-3 p-4">
        {isLoading ? (
          <div className="flex justify-center py-16">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : orders.length === 0 ? (
          <p className="py-16 text-center text-sm text-muted-foreground">Bu listede sipariş yok.</p>
        ) : (
          orders.map((order) => (
            <Card key={order.id} className="overflow-hidden">
              <div className="flex items-center justify-between gap-2 border-b bg-muted/40 px-4 py-3">
                <div>
                  <p className="text-base font-bold leading-tight">Masa {order.tableNo}</p>
                  <p className="text-xs text-muted-foreground">
                    #{order.orderNo} · {formatTime(order.createdAt)} · {timeAgo(order.createdAt)}
                  </p>
                </div>
                <Badge variant="outline" className={ORDER_STATUS_CLASS[order.status]}>
                  {ORDER_STATUS_LABEL[order.status]}
                </Badge>
              </div>

              <ul className="divide-y">
                {order.orderItems.map((item) => (
                  <li key={item.id} className="flex gap-3 px-4 py-3">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-primary text-sm font-bold text-primary-foreground">
                      {item.quantity}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold leading-tight">{item.productName}</p>
                      {item.selectedOptions.length > 0 && (
                        <div className="mt-1.5 flex flex-wrap gap-1.5">
                          {item.selectedOptions.map((o) => (
                            <span
                              key={o.id}
                              className="rounded-md bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-900"
                            >
                              {o.choiceName}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                    <span className="shrink-0 text-sm text-muted-foreground tabular-nums">
                      {formatPrice(item.totalPrice)}
                    </span>
                  </li>
                ))}
              </ul>

              {order.notes && (
                <p className="border-t bg-amber-50 px-4 py-2.5 text-sm text-amber-900">
                  <span className="font-semibold">Not:</span> {order.notes}
                </p>
              )}

              <div className="flex items-center justify-between border-t px-4 py-3">
                <span className="font-bold tabular-nums">{formatPrice(order.totalAmount)}</span>
                <div className="flex gap-2">
                  {order.status === "PENDING" && (
                    <>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => mutation.mutate({ id: order.id, status: "CANCELLED" })}
                        disabled={mutation.isPending}
                      >
                        <X className="h-4 w-4" />
                        İptal
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => mutation.mutate({ id: order.id, status: "PREPARING" })}
                        disabled={mutation.isPending}
                      >
                        <ChefHat className="h-4 w-4" />
                        Hazırla
                      </Button>
                    </>
                  )}
                  {order.status === "PREPARING" && (
                    <Button
                      size="sm"
                      variant="success"
                      onClick={() => mutation.mutate({ id: order.id, status: "COMPLETED" })}
                      disabled={mutation.isPending}
                    >
                      <CheckCircle2 className="h-4 w-4" />
                      Teslim Et
                    </Button>
                  )}
                  {order.status === "COMPLETED" && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => mutation.mutate({ id: order.id, status: "PREPARING" })}
                      disabled={mutation.isPending}
                    >
                      Geri Al
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
