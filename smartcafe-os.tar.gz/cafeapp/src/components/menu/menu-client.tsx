"use client";

import * as React from "react";
import Image from "next/image";
import { Coffee, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ProductDrawer } from "@/components/menu/product-drawer";
import { CartDrawer } from "@/components/menu/cart-drawer";
import { formatPrice } from "@/lib/utils";
import { cartCount, cartTotal, useCart } from "@/store/cart";
import type { CategoryDTO, ProductDTO } from "@/types/menu";

export function MenuClient({ tableNo, categories }: { tableNo: string; categories: CategoryDTO[] }) {
  const setTableNo = useCart((s) => s.setTableNo);
  const items = useCart((s) => s.items);
  const [mounted, setMounted] = React.useState(false);
  const [activeProduct, setActiveProduct] = React.useState<ProductDTO | null>(null);
  const [productOpen, setProductOpen] = React.useState(false);
  const [cartOpen, setCartOpen] = React.useState(false);
  const [activeCategory, setActiveCategory] = React.useState(categories[0]?.id ?? "");

  React.useEffect(() => {
    setMounted(true);
    setTableNo(tableNo);
  }, [tableNo, setTableNo]);

  const openProduct = (product: ProductDTO) => {
    setActiveProduct(product);
    setProductOpen(true);
  };

  const scrollToCategory = (id: string) => {
    setActiveCategory(id);
    document.getElementById(`kat-${id}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const count = mounted ? cartCount(items) : 0;
  const total = mounted ? cartTotal(items) : 0;

  return (
    <div className="min-h-[100dvh] bg-background pb-28">
      <header className="sticky top-0 z-30 border-b bg-background/95 backdrop-blur safe-top">
        <div className="flex items-center gap-3 px-4 py-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <Coffee className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <h1 className="truncate text-lg font-bold leading-tight">SmartCafe</h1>
            <p className="text-xs text-muted-foreground">Masa {tableNo}</p>
          </div>
        </div>

        {categories.length > 0 && (
          <nav className="no-scrollbar flex gap-2 overflow-x-auto px-4 pb-3">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => scrollToCategory(cat.id)}
                className={`whitespace-nowrap rounded-full border px-3.5 py-1.5 text-sm transition-colors ${
                  activeCategory === cat.id
                    ? "border-primary bg-primary text-primary-foreground"
                    : "bg-background text-muted-foreground"
                }`}
              >
                {cat.name}
              </button>
            ))}
          </nav>
        )}
      </header>

      <main className="px-4">
        {categories.length === 0 ? (
          <p className="py-20 text-center text-sm text-muted-foreground">
            Menü henüz hazırlanıyor. Lütfen personelimize danışın.
          </p>
        ) : (
          categories.map((cat) => (
            <section key={cat.id} id={`kat-${cat.id}`} className="scroll-mt-32 pt-5">
              <h2 className="mb-3 text-base font-bold">{cat.name}</h2>
              <div className="space-y-3">
                {cat.products.map((product) => (
                  <button
                    key={product.id}
                    onClick={() => openProduct(product)}
                    className="flex w-full items-center gap-3 rounded-xl border bg-card p-3 text-left transition-colors active:bg-accent/50"
                  >
                    {product.imageUrl ? (
                      <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-lg bg-muted">
                        <Image src={product.imageUrl} alt={product.name} fill className="object-cover" sizes="80px" />
                      </div>
                    ) : (
                      <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground">
                        <Coffee className="h-7 w-7" />
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold leading-tight">{product.name}</p>
                      {product.description && (
                        <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground">{product.description}</p>
                      )}
                      <p className="mt-1.5 font-semibold text-primary tabular-nums">{formatPrice(product.price)}</p>
                      {product.options.length > 0 && (
                        <p className="text-[11px] text-muted-foreground">Seçenekler mevcut</p>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </section>
          ))
        )}
      </main>

      {count > 0 && (
        <div className="fixed inset-x-0 bottom-0 z-40 border-t bg-background/95 p-3 backdrop-blur safe-bottom">
          <Button size="lg" className="w-full justify-between" onClick={() => setCartOpen(true)}>
            <span className="flex items-center gap-2">
              <ShoppingBag className="h-5 w-5" />
              Sepeti Görüntüle ({count})
            </span>
            <span className="tabular-nums">{formatPrice(total)}</span>
          </Button>
        </div>
      )}

      <ProductDrawer product={activeProduct} open={productOpen} onOpenChange={setProductOpen} />
      <CartDrawer open={cartOpen} onOpenChange={setCartOpen} tableNo={tableNo} />
    </div>
  );
}
