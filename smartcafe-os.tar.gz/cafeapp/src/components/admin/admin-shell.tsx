"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
import { BarChart3, Coffee, LayoutDashboard, LogOut, QrCode, ReceiptText, Wallet } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

const NAV = [
  { href: "/yonetim", label: "Özet", icon: LayoutDashboard },
  { href: "/yonetim/menu", label: "Menü", icon: Coffee },
  { href: "/yonetim/siparisler", label: "Siparişler", icon: ReceiptText },
  { href: "/yonetim/finans", label: "Finans", icon: Wallet },
  { href: "/yonetim/qr", label: "QR", icon: QrCode },
];

export function AdminShell({ children, userName }: { children: React.ReactNode; userName: string }) {
  const pathname = usePathname();
  const isActive = (href: string) => (href === "/yonetim" ? pathname === href : pathname.startsWith(href));

  return (
    <div className="min-h-[100dvh] bg-background md:flex">
      {/* Masaustu kenar cubugu */}
      <aside className="hidden w-60 shrink-0 border-r p-4 md:flex md:flex-col">
        <div className="mb-6 flex items-center gap-2 px-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <BarChart3 className="h-5 w-5" />
          </div>
          <div>
            <p className="text-sm font-bold leading-tight">SmartCafe</p>
            <p className="text-xs text-muted-foreground">{userName}</p>
          </div>
        </div>
        <nav className="flex-1 space-y-1">
          {NAV.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                isActive(href) ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted"
              )}
            >
              <Icon className="h-4 w-4" />
              {label}
            </Link>
          ))}
        </nav>
        <Button variant="ghost" className="justify-start" onClick={() => signOut({ callbackUrl: "/giris" })}>
          <LogOut className="h-4 w-4" />
          Çıkış Yap
        </Button>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        {/* Mobil ust bar */}
        <header className="sticky top-0 z-30 flex items-center justify-between border-b bg-background/95 px-4 py-3 backdrop-blur safe-top md:hidden">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <BarChart3 className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-bold leading-tight">Yönetim</p>
              <p className="text-xs text-muted-foreground">{userName}</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={() => signOut({ callbackUrl: "/giris" })} aria-label="Çıkış">
            <LogOut className="h-5 w-5" />
          </Button>
        </header>

        <main className="flex-1 p-4 pb-24 md:pb-8">{children}</main>

        {/* Mobil alt gezinme */}
        <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t bg-background/95 backdrop-blur safe-bottom md:hidden">
          {NAV.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-medium",
                isActive(href) ? "text-primary" : "text-muted-foreground"
              )}
            >
              <Icon className="h-5 w-5" />
              {label}
            </Link>
          ))}
        </nav>
      </div>
    </div>
  );
}
