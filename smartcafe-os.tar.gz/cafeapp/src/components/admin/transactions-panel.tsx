"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Loader2, Lock, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { deleteTransaction, saveTransaction } from "@/app/yonetim/actions";
import { EXPENSE_CATEGORIES } from "@/lib/constants";
import { formatDate, formatPrice } from "@/lib/utils";
import { toast } from "sonner";

export type TransactionRow = {
  id: string;
  type: "INCOME" | "EXPENSE";
  amount: number;
  description: string;
  category: string | null;
  date: string;
  isAutomatic: boolean;
};

export function TransactionsPanel({ transactions }: { transactions: TransactionRow[] }) {
  const router = useRouter();
  const [open, setOpen] = React.useState(false);
  const [saving, setSaving] = React.useState(false);
  const [filter, setFilter] = React.useState<"ALL" | "INCOME" | "EXPENSE">("ALL");

  const [form, setForm] = React.useState({
    type: "EXPENSE" as "INCOME" | "EXPENSE",
    amount: "",
    description: "",
    category: EXPENSE_CATEGORIES[0] as string,
    date: new Date().toISOString().slice(0, 10),
  });

  const visible = transactions.filter((t) => (filter === "ALL" ? true : t.type === filter));

  const submit = async () => {
    setSaving(true);
    const res = await saveTransaction({ ...form, amount: Number(form.amount) });
    setSaving(false);
    if (!res.ok) return toast.error(res.error);
    toast.success(form.type === "EXPENSE" ? "Gider eklendi" : "Gelir eklendi");
    setOpen(false);
    setForm((f) => ({ ...f, amount: "", description: "" }));
    router.refresh();
  };

  const remove = async (row: TransactionRow) => {
    if (!window.confirm("Bu kayıt silinsin mi?")) return;
    const res = await deleteTransaction(row.id);
    if (!res.ok) return toast.error(res.error);
    toast.success("Kayıt silindi");
    router.refresh();
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Tabs value={filter} onValueChange={(v) => setFilter(v as typeof filter)}>
          <TabsList>
            <TabsTrigger value="ALL">Tümü</TabsTrigger>
            <TabsTrigger value="INCOME">Gelir</TabsTrigger>
            <TabsTrigger value="EXPENSE">Gider</TabsTrigger>
          </TabsList>
        </Tabs>
        <Button onClick={() => setOpen(true)}>
          <Plus className="h-4 w-4" />
          Kayıt Ekle
        </Button>
      </div>

      {visible.length === 0 ? (
        <Card className="p-8 text-center text-sm text-muted-foreground">Bu filtrede kayıt yok.</Card>
      ) : (
        <Card className="divide-y">
          {visible.map((t) => (
            <div key={t.id} className="flex items-center gap-3 p-3">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="text-sm font-medium">{t.description}</p>
                  {t.isAutomatic && (
                    <Badge variant="secondary" className="gap-1 text-[10px]">
                      <Lock className="h-2.5 w-2.5" />
                      Otomatik
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  {formatDate(t.date)}
                  {t.category ? ` · ${t.category}` : ""}
                </p>
              </div>
              <span
                className={`shrink-0 text-sm font-semibold tabular-nums ${
                  t.type === "INCOME" ? "text-emerald-700" : "text-rose-700"
                }`}
              >
                {t.type === "INCOME" ? "+" : "−"}
                {formatPrice(t.amount)}
              </span>
              {!t.isAutomatic && (
                <Button variant="ghost" size="icon" onClick={() => remove(t)} aria-label="Sil">
                  <Trash2 className="h-4 w-4 text-muted-foreground" />
                </Button>
              )}
            </div>
          ))}
        </Card>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Yeni Kayıt</DialogTitle>
            <DialogDescription>Manuel gelir veya gider ekleyin.</DialogDescription>
          </DialogHeader>

          <div className="space-y-3">
            <Tabs value={form.type} onValueChange={(v) => setForm((f) => ({ ...f, type: v as "INCOME" | "EXPENSE" }))}>
              <TabsList className="w-full">
                <TabsTrigger value="EXPENSE" className="flex-1">
                  Gider
                </TabsTrigger>
                <TabsTrigger value="INCOME" className="flex-1">
                  Gelir
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="space-y-1.5">
              <Label htmlFor="tutar">Tutar (₺)</Label>
              <Input
                id="tutar"
                type="number"
                step="0.01"
                min="0"
                inputMode="decimal"
                value={form.amount}
                onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))}
                placeholder="0,00"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="aciklama">Açıklama</Label>
              <Input
                id="aciklama"
                value={form.description}
                onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                placeholder="Örn. Süt ve kahve çekirdeği alımı"
              />
            </div>

            <div className="space-y-1.5">
              <Label>Kategori</Label>
              <Select value={form.category} onValueChange={(v) => setForm((f) => ({ ...f, category: v }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Kategori" />
                </SelectTrigger>
                <SelectContent>
                  {EXPENSE_CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="tarih">Tarih</Label>
              <Input
                id="tarih"
                type="date"
                value={form.date}
                onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))}
              />
            </div>

            <div className="flex justify-end gap-2 pt-1">
              <Button variant="outline" onClick={() => setOpen(false)}>
                Vazgeç
              </Button>
              <Button onClick={submit} disabled={saving || !form.amount || !form.description.trim()}>
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Kaydet"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
