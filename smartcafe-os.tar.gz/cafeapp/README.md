# SmartCafe OS

Kafe yönetim, QR dijital menü, sipariş takibi (KDS) ve gelir–gider sistemi.
Next.js 14 (App Router) · Prisma · PostgreSQL · NextAuth · Tailwind + Shadcn UI · PWA.

---

## Kurulum (adım adım)

### 1. Paketleri yükle

```bash
npm install
```

### 2. Veritabanını hazırla

Ücretsiz bir PostgreSQL alabileceğin iki yer:

**Supabase** (önerilen)
1. https://supabase.com → yeni proje oluştur (bölge: Frankfurt/Central EU en yakını).
2. Project Settings → Database → **Connection string → URI**.
3. `Transaction pooler` adresini `DATABASE_URL`, `Direct connection` adresini `DIRECT_URL` olarak kullan.

**Neon**
1. https://neon.tech → yeni proje.
2. Dashboard → Connection string → hem `DATABASE_URL` hem `DIRECT_URL` için aynısını kullanabilirsin.

### 3. Ortam değişkenleri

`.env.example` dosyasını `.env` olarak kopyala ve doldur:

```bash
cp .env.example .env
```

`NEXTAUTH_SECRET` üretmek için:

```bash
openssl rand -base64 32
```

### 4. Tabloları oluştur ve örnek menüyü yükle

```bash
npm run db:push     # şemayı veritabanına yazar
npm run db:seed     # yönetici + personel hesabı ve örnek menü
```

Seed sonrası giriş bilgileri (`.env` içinden değiştirilebilir):

| Rol | E-posta | Şifre |
|---|---|---|
| Yönetici | `admin@smartcafe.local` | `admin123` |
| Personel | `barista@smartcafe.local` | `barista123` |

> İlk girişten sonra bu şifreleri mutlaka değiştir (veya `.env`'de kendi bilgilerinle seed'i çalıştır).

### 5. Çalıştır

```bash
npm run dev
```

http://localhost:3000

---

## Ekranlar

| Adres | Kim kullanır | Ne yapar |
|---|---|---|
| `/menu/[masaNo]` | Müşteri | QR ile açılan menü, seçenekli ürün ekleme, sepet, sipariş |
| `/menu` | Müşteri | Masa numarası girip menüye geçiş |
| `/kds` | Personel | Aktif siparişler, "Hazırla / Teslim et / İptal" |
| `/yonetim` | Yönetici | Günlük özet, grafik, en çok satanlar |
| `/yonetim/menu` | Yönetici | Kategori + ürün + seçenek grubu yönetimi |
| `/yonetim/siparisler` | Yönetici | Sipariş geçmişi ve detayları |
| `/yonetim/finans` | Yönetici | Gelir/gider kayıtları, kâr marjı |
| `/yonetim/qr` | Yönetici | Masa QR kodlarını üret, indir, yazdır |

---

## Nasıl çalışıyor (önemli detaylar)

**Fiyat hesabı sunucuda yapılır.** `POST /api/orders` isteğinde istemciden gelen
fiyatlar dikkate alınmaz; ürün ve seçenek fiyatları veritabanından tekrar okunup
toplam yeniden hesaplanır. Zorunlu seçenek kontrolü de sunucuda yapılır.

**Sipariş geçmişi bozulmaz.** Müşterinin seçtiği seçenekler `OrderItemOption`
tablosuna *metin olarak* (optionName, choiceName, extraPrice) kopyalanır. Yönetici
ileride "Süt Tercihi" grubunu silse bile eski fişler olduğu gibi kalır. Ürün adı da
`OrderItem.productName` alanında saklanır.

**Gelir otomatik işlenir.** Bir sipariş `COMPLETED` yapıldığında sipariş tutarı
kadar `INCOME` tipinde bir `Transaction` oluşur (`orderId` ile bire bir bağlı, bu
yüzden çift kayıt oluşamaz). Sipariş tamamlanmış durumdan çıkarılırsa bu gelir
kaydı otomatik silinir. Otomatik gelirler finans ekranından elle silinemez.

**Sepet gruplaması.** Aynı ürün + aynı seçim kombinasyonu tek satırda toplanır;
farklı seçim yapılırsa ayrı satır olur (`buildLineId`).

**PWA.** `next-pwa` (`@ducanh2912/next-pwa`) ile service worker üretilir ve
`public/manifest.json` ile telefona "Ana ekrana ekle" yapılabilir. Service worker
sadece production build'de aktiftir (`npm run build && npm start`).

---

## Yayına alma (Vercel)

1. Projeyi GitHub'a at.
2. https://vercel.com → Import Project.
3. Environment Variables kısmına `.env` içindekileri ekle
   (`NEXTAUTH_URL` değerini gerçek alan adın yap, örn. `https://kafem.vercel.app`).
4. Deploy.
5. `/yonetim/qr` sayfasında "Site adresi" alanına yayın adresini yaz, QR kodları
   yeniden üret ve yazdır.

---

## Komutlar

| Komut | Ne yapar |
|---|---|
| `npm run dev` | Geliştirme sunucusu |
| `npm run build` | Prisma client üretir + production build |
| `npm start` | Production sunucusu (PWA burada aktif) |
| `npm run db:push` | Şemayı veritabanına uygular |
| `npm run db:seed` | Örnek veri + kullanıcılar |
| `npm run db:studio` | Prisma Studio (veritabanı arayüzü) |

---

## Sonraki adımlar için fikirler

- Ürün görselleri için Supabase Storage / UploadThing entegrasyonu
- KDS'te yeni sipariş geldiğinde sesli uyarı ve web push bildirimi
- Adisyon/fiş yazıcısı (ESC/POS) entegrasyonu
- Masa bazlı açık hesap ve ödeme yöntemi (nakit/kart) kaydı
- Personel vardiya ve satış performansı raporu
